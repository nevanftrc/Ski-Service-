# Swagger
Install Dependencies for swagger
$ npm i swagger-ui-express -S


